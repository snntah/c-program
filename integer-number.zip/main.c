#include<stdio.h>
int main()
{
  float num1,num2,mul;
  printf("enter a number");
  scanf("%f",&num1);
  printf("enter a number");
  scanf("%f",&num2);
  mul=num1*num2;
  printf("the multiplied value is %f",mul);
  return 0;
}